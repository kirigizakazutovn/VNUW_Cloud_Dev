const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "help",
  description: "Thông tin và lệnh của bot",
  usage: "[command]",
  permissions: {
    channel: ["VIEW_CHANNEL", "SEND_MESSAGES", "EMBED_LINKS"],
    member: [],
  },
  aliases: ["command", "commands", "cmd"],
  /**
   *
   * @param {import("../structures/DiscordMusicBot")} client
   * @param {import("discord.js").Message} message
   * @param {string[]} args
   * @param {*} param3
   */
  run: async (client, message, args, { GuildDB }) => {
    let Commands = client.commands.map(
      (cmd) =>
        `\`${GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix}${
          cmd.name
        }${cmd.usage ? " " + cmd.usage : ""}\` - ${cmd.description}`
    );

    let Embed = new MessageEmbed()
      .setAuthor(
        `Các lệnh của ${client.user.username}`,
        client.botconfig.IconURL
      )
      .setColor(client.botconfig.EmbedColor)
      .setFooter(
        `Để nhận thông tin về từng loại lệnh, nhập ${
          GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix
        }help [Command] 
Để thay đổi dấu ! trước các lệnh, nhập ${
                GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix
              }config | Chúc các bạn một ngày tốt lành!✨`
      ).setDescription(`${Commands.join("\n")}
  
  DYLLO Music Bot Phiên Bản: v${require("../package.json").version}
  [✨ Server Hỗ Trợ](${
    client.botconfig.SupportServer
  }) | [Youtube](https://www.youtube.com/channel/UCPA2fmJkt3TS8CmOPxL1ujw) | Made by [Fong Trần](https://www.facebook.com/myinmyhearth)`);
    if (!args[0]) message.channel.send(Embed);
    else {
      let cmd =
        client.commands.get(args[0]) ||
        client.commands.find((x) => x.aliases && x.aliases.includes(args[0]));
      if (!cmd)
        return client.sendTime(
          message.channel,
          `❌ | Không thể tìm thấy lệnh đó.`
        );

      let embed = new MessageEmbed()
        .setAuthor(`Command: ${cmd.name}`, client.botconfig.IconURL)
        .setDescription(cmd.description)
        .setColor("GREEN")
        //.addField("Name", cmd.name, true)
        .addField("Aliases", `\`${cmd.aliases.join(", ")}\``, true)
        .addField(
          "Usage",
          `\`${GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix}${
            cmd.name
          }${cmd.usage ? " " + cmd.usage : ""}\``,
          true
        )
        .addField(
          "Permissions",
          "Member: " +
            cmd.permissions.member.join(", ") +
            "\nBot: " +
            cmd.permissions.channel.join(", "),
          true
        )
        .setFooter(
          `Prefix - ${
            GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix
          }`
        );

      message.channel.send(embed);
    }
  },

  SlashCommand: {
    options: [
      {
        name: "command",
        description: "Nhận thông tin về một lệnh cụ thể",
        value: "command",
        type: 3,
        required: false,
      },
    ],
    /**
     *
     * @param {import("../structures/DiscordMusicBot")} client
     * @param {import("discord.js").Message} message
     * @param {string[]} args
     * @param {*} param3
     */

    run: async (client, interaction, args, { GuildDB }) => {
      let Commands = client.commands.map(
        (cmd) =>
          `\`${GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix}${
            cmd.name
          }${cmd.usage ? " " + cmd.usage : ""}\` - ${cmd.description}`
      );

      let Embed = new MessageEmbed()
        .setAuthor(
          `Lệnh của ${client.user.username}`,
          client.botconfig.IconURL
        )
        .setColor(client.botconfig.EmbedColor)
        .setFooter(
          `Để nhận thông tin của từng loại lệnh, nhập ${
            GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix
          }help [Command] 
Để thay đổi dấu ! trước các lệnh, nhập ${
                GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix
              } | Chúc các bạn một ngày tốt lành!✨`
            ).setDescription(`${Commands.join("\n")}
  
 DYLLO Music Bot Phiên Bản: v${require("../package.json").version}
  [✨ Server Hỗ Trợ](${
    client.botconfig.SupportServer
  }) | [Youtube](https://www.youtube.com/channel/UCPA2fmJkt3TS8CmOPxL1ujw) | Made by [Fong Trần](https://www.facebook.com/myinmyhearth)`);
      if (!args) return interaction.send(Embed);
      else {
        let cmd =
          client.commands.get(args[0].value) ||
          client.commands.find(
            (x) => x.aliases && x.aliases.includes(args[0].value)
          );
        if (!cmd)
          return client.sendTime(
            interaction,
            `❌ | Không thể tìm thấy lệnh đó.`
          );

        let embed = new MessageEmbed()
          .setAuthor(`Command: ${cmd.name}`, client.botconfig.IconURL)
          .setDescription(cmd.description)
          .setColor("GREEN")
          //.addField("Name", cmd.name, true)
          .addField("Aliases", cmd.aliases.join(", "), true)
          .addField(
            "Usage",
            `\`${GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix}${
              cmd.name
            }\`${cmd.usage ? " " + cmd.usage : ""}`,
            true
          )
          .addField(
            "Permissions",
            "Member: " +
              cmd.permissions.member.join(", ") +
              "\nBot: " +
              cmd.permissions.channel.join(", "),
            true
          )
          .setFooter(
            `Prefix - ${
              GuildDB ? GuildDB.prefix : client.botconfig.DefaultPrefix
            }`
          );

        interaction.send(embed);
      }
    },
  },
};
