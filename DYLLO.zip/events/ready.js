module.exports = async (client) => {
  client.Ready = true, 
  client.user.setPresence({
    status: "online",  // You can show online, idle, and dnd
    activity: {
        name: `nhạc trong ${client.guilds.cache.size} servers.`,  // The message shown
        type: "STREAMING",url: "https://www.twitch.tv/testerislive" // PLAYING, WATCHING, LISTENING, STREAMING,
    }
});
  client.Manager.init(client.user.id);
  client.log("Đăng nhập thành công với tư cách là " + client.user.tag); // You can change the text if you want, but DO NOT REMOVE "client.user.tag"
  client.RegisterSlashCommands();
};
